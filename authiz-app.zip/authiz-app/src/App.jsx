import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { UploadCloud, Download, Pencil } from 'lucide-react';
import { PDFDocument, rgb } from 'pdf-lib';

export default function AuthizApp() {
  const [pdfFile, setPdfFile] = useState(null);
  const [signedPdfUrl, setSignedPdfUrl] = useState(null);

  const handleFileChange = (e) => {
    setPdfFile(e.target.files[0]);
    setSignedPdfUrl(null);
  };

  const signPDF = async () => {
    if (!pdfFile) return;

    const fileArrayBuffer = await pdfFile.arrayBuffer();
    const pdfDoc = await PDFDocument.load(fileArrayBuffer);
    const pages = pdfDoc.getPages();
    const firstPage = pages[0];

    const { width, height } = firstPage.getSize();
    firstPage.drawText('Signed by Authiz', {
      x: width - 150,
      y: 50,
      size: 12,
      color: rgb(0, 0, 0),
    });

    const signedPdfBytes = await pdfDoc.save();
    const blob = new Blob([signedPdfBytes], { type: 'application/pdf' });
    const url = URL.createObjectURL(blob);
    setSignedPdfUrl(url);
  };

  const clearSession = () => {
    setPdfFile(null);
    setSignedPdfUrl(null);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-100 p-6">
      <Card className="w-full max-w-md p-6">
        <CardContent className="space-y-4">
          <h1 className="text-2xl font-bold text-center">authiz.com</h1>
          <p className="text-sm text-center text-gray-500">
            No uploads. No tracking. GDPR-ready. All processing happens in your browser.
          </p>

          <Input type="file" accept="application/pdf" onChange={handleFileChange} />

          <Button onClick={signPDF} disabled={!pdfFile} className="w-full">
            <Pencil className="mr-2 h-4 w-4" /> Sign PDF
          </Button>

          {signedPdfUrl && (
            <>
              <a href={signedPdfUrl} download="signed.pdf">
                <Button className="w-full mt-2">
                  <Download className="mr-2 h-4 w-4" /> Download Signed PDF
                </Button>
              </a>
              <Button onClick={clearSession} variant="ghost" className="w-full text-xs text-gray-400 mt-1">
                Clear and start over
              </Button>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
